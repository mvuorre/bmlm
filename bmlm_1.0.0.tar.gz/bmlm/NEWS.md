# bmlm 1.0.0

Initial release to CRAN.
